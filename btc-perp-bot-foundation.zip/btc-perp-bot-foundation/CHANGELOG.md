# Changelog

## Unreleased

### Added

- Repository documentation foundation
- Architecture, roadmap, risk, deployment, strategy, and Avantis integration documentation
- Safety-first contribution workflow
