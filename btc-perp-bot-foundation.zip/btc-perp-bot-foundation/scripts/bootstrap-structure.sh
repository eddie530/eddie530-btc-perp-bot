#!/usr/bin/env bash
set -euo pipefail

mkdir -p   docs   src/{strategy,risk,execution,exchange,wallet,state,rpc,indicators,logging,utils}   tests scripts docker .github/workflows examples

echo "Repository structure created."
echo "Safety default: DRY_RUN=true"
