# Tasks

## P0 — Required Before Live Execution

- [ ] Pin verified Avantis addresses
- [ ] Verify BTC/USD pair index
- [ ] Implement typed transaction builder
- [ ] Add pre-send simulation
- [ ] Add wallet balance checks
- [ ] Add USDC allowance checks
- [ ] Add ETH gas-balance checks
- [ ] Add nonce protection
- [ ] Add idempotency protection
- [ ] Add duplicate-order prevention
- [ ] Add position reconciliation
- [ ] Add unknown-position fail-closed behavior
- [ ] Add structured simulation logs
- [ ] Add explicit operator approval gate

## P1 — Reliability

- [ ] Add metrics
- [ ] Add alerting
- [ ] Add emergency kill switch
- [ ] Add restart recovery tests
- [ ] Add RPC degradation tests

## P2 — Product

- [ ] Add dashboard
- [ ] Add trade journal
- [ ] Add backtesting
- [ ] Add paper/live comparison
