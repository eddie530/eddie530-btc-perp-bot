# BTC Perp Bot — Project Chat Summary

## Purpose

This document captures the key decisions, constraints, implementation status, and next steps discussed while building the safety-first Avantis BTC/USD perpetual trading bot on Base.

## Project Goal

Build a TypeScript BTC perpetual trading bot that:

- Uses BTC price data and an EMA-based strategy.
- Applies conservative position, leverage, loss, cooldown, take-profit, and stop-loss rules.
- Persists state.
- Uses Base RPC failover.
- Defaults to dry-run mode.
- Refuses to sign or broadcast live transactions until all live-mode gates are complete.

## Current Repository Status

The repository has been described as including:

- TypeScript bot architecture.
- BTC price feed.
- EMA strategy.
- 3x default leverage.
- 5x hard leverage ceiling.
- Maximum example notional of 100 USDC.
- Daily-loss and cooldown safeguards.
- Required TP and SL on every order intent.
- Base RPC failover.
- Persistent state.
- Avantis address-fetching helper.
- GitHub Actions CI.
- Docker files.
- Dry-run execution.
- Locked live executor.

Reported validation:

- TypeScript checks passed.
- 10 of 10 tests passed.
- Smoke test passed.
- Simulated BTC long generated.
- No transaction was signed or broadcast.

## Non-Negotiable Safety Rules

1. Keep `DRY_RUN=true` as the default in code, examples, CI, Docker, and deployment manifests.
2. Never commit private keys, seed phrases, API keys, wallet exports, or a populated `.env`.
3. Every change must pass:
   - `npm run check`
   - `npm run smoke`
4. Use feature branches and pull requests for material changes.
5. Do not enable live execution until all required live-mode gates are complete.
6. Do not exceed 5x leverage or the configured notional cap without a separate risk review.
7. Strategy changes require replay or backtest evidence.
8. Fail closed on stale data, RPC uncertainty, balance mismatch, allowance mismatch, unknown positions, or reconciliation errors.

## Standard Setup

```bash
cp .env.example .env
npm install
npm run check
npm run build
npm run smoke
```

Run continuous dry-run mode:

```bash
DRY_RUN=true npm start
```

## Live-Mode Gates

Live trading must remain disabled until all of the following are complete:

- Verified and pinned Avantis Base contract addresses.
- Verified BTC/USD pair index.
- Audited typed transaction-builder adapter.
- Pre-send transaction simulation.
- Wallet configuration.
- Nonce protection.
- Idempotency and duplicate-order protection.
- Position reconciliation against on-chain state.
- USDC balance and allowance checks.
- ETH gas-balance checks.
- Stale-price protection.
- RPC fail-closed behavior.
- Simulation logs.
- Explicit operator approval.

## Recommended Implementation Order

1. Verify and pin Avantis contract addresses.
2. Verify BTC/USD pair index and protocol parameters.
3. Implement a typed open/close transaction builder.
4. Add transaction simulation before signing.
5. Add nonce and idempotency protection.
6. Add on-chain position reconciliation.
7. Add collateral, allowance, gas, stale-data, and RPC checks.
8. Add unit tests and dry-run replay evidence.
9. Open a feature-branch pull request.
10. Keep live execution locked until final review and approval.

## GitHub Repository

Target repository:

```text
eddie530/btc-perp-bot
```

Suggested location for this document:

```text
docs/PROJECT_CHAT.md
```

## Security Note

An OpenAI API key was previously shared in chat. It must be treated as exposed and revoked. No secret, private key, seed phrase, wallet export, API credential, or populated `.env` should be added to this repository.

## Decision Log

- Dry-run mode remains the default.
- No live trade should be placed from the current scaffold.
- The live executor must continue to throw or refuse execution until the P0 safety gates are complete.
- Continuous bot hosting must run on a local machine or deployment environment, not inside a chat session.
- The repository should use feature branches and pull requests for material implementation work.
