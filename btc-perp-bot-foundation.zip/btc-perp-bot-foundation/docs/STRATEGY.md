# Strategy

## Current Strategy

The current scaffold uses an EMA-based BTC signal engine.

## Required Evidence

Any strategy change must include:

- Replay or backtest evidence
- Entry and exit assumptions
- Fee and slippage assumptions
- Risk-rule interaction tests
- False-positive and false-negative review

## Separation of Concerns

The strategy proposes signals. It does not control leverage, position size, or execution permissions.
