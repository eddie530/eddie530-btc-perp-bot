# Contributing

1. Create a feature branch.
2. Make one focused change.
3. Add or update tests.
4. Run:

```bash
npm run check
npm run smoke
```

5. Open a pull request.
6. Do not weaken safety defaults.
7. Do not enable live execution without completing all live-mode gates.
