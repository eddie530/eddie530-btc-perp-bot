# Roadmap

## Phase 1 — Dry Run

- [x] Price feed
- [x] EMA signal engine
- [x] Risk gates
- [x] Persistent state
- [x] RPC failover
- [x] Dry-run executor
- [x] Smoke test

## Phase 2 — Live-Mode Safety Infrastructure

- [ ] Pin verified Avantis contract addresses
- [ ] Verify BTC/USD pair index
- [ ] Typed transaction builder
- [ ] Pre-send transaction simulation
- [ ] USDC balance and allowance checks
- [ ] ETH gas-balance check
- [ ] Nonce protection
- [ ] Idempotency key
- [ ] Duplicate-order protection
- [ ] Position reconciliation
- [ ] Unknown-position fail-closed behavior
- [ ] Simulation logs
- [ ] Operator approval gate

## Phase 3 — Controlled Live Pilot

- [ ] Minimum notional pilot
- [ ] 3x leverage maximum
- [ ] One position at a time
- [ ] Manual approval required
- [ ] Daily loss cap verified
- [ ] Emergency kill switch tested

## Phase 4 — Observability

- [ ] Dashboard
- [ ] Telegram alerts
- [ ] Trade journal
- [ ] Performance analytics
- [ ] Paper/live comparison
