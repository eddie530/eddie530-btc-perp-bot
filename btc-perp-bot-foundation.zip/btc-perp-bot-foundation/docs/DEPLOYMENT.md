# Deployment

## Required Principle

All environments must default to:

```bash
DRY_RUN=true
```

## Local

```bash
cp .env.example .env
npm install
npm run check
npm run build
npm run smoke
DRY_RUN=true npm start
```

## Docker

The Docker image and deployment manifest must not contain secrets. Supply secrets at runtime.

## Production Readiness Gate

Do not deploy live execution until:

- All P0 tasks are complete.
- Tests and smoke checks pass.
- Simulation logs are reviewed.
- Position reconciliation is verified.
- Operator approval is explicit.
