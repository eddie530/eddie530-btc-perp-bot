# Avantis Integration

## Current Status

Live open/close transaction signing is not implemented and must remain locked.

## Required Before Live Mode

- Verified and pinned Base contract addresses
- Verified BTC/USD pair index
- Typed transaction builder
- Simulation before signing
- USDC collateral checks
- ETH gas checks
- Position reconciliation
- Nonce and idempotency protection
- Explicit operator approval

## Security

Never commit private keys, wallet exports, API keys, seed phrases, or a populated `.env`.
