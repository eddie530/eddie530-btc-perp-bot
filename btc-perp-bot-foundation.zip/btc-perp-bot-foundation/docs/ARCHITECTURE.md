# Architecture

## Objective

Provide a safety-first BTC/USD perpetual trading system for Avantis on Base.

## Data Flow

```text
Price Feed
    |
    v
EMA Strategy
    |
    v
Risk Engine
    |
    v
Position Reconciliation
    |
    v
Dry-Run Executor
    |
    v
Live Executor (LOCKED)
```

## Components

### Price Feed
Reads BTC spot data and rejects stale or malformed prices.

### Strategy
Builds EMA-based trade signals. Strategy changes require replay or backtest evidence.

### Risk Engine
Enforces leverage, notional, stop-loss, take-profit, cooldown, daily-loss, and one-position rules.

### State Store
Persists strategy state, order intents, cooldown state, and reconciliation metadata.

### RPC Layer
Uses Base RPC failover. Transport uncertainty must pause new orders.

### Executor
Dry-run execution records intents only. Live execution must remain locked until all P0 gates are complete.
