# Risk Controls

## Default Limits

- `DRY_RUN=true`
- Default leverage: 3x
- Hard leverage ceiling: 5x
- Example maximum notional: 100 USDC
- One directional position at a time
- Stop-loss required
- Take-profit required
- Daily loss cap enforced
- Cooldown enforced

## Fail-Closed Conditions

New orders must be blocked when any of the following occur:

- RPC uncertainty
- Stale or malformed market data
- Balance mismatch
- Allowance mismatch
- Unknown open position
- Position reconciliation failure
- Simulation failure
- Nonce conflict
- Duplicate order intent
- Insufficient ETH for gas
- Missing verified protocol configuration

## Change Control

Any change to leverage, notional, strategy, or loss limits requires a separate risk review and test evidence.
